-- Migration: profile photo (avatar) support.
-- Adds the avatar column used by the Users section (change your username,
-- password, and upload your profile photo).
ALTER TABLE users ADD COLUMN avatar VARCHAR(255) NULL AFTER account_no;