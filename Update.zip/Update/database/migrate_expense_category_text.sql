-- Expense category becomes free text: the expenses.php form now uses a textbox
-- (with suggestions) instead of a fixed dropdown, so the DB column is widened
-- from an ENUM to a plain string.
ALTER TABLE expenses MODIFY category VARCHAR(80) NOT NULL;