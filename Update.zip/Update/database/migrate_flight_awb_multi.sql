-- Migration: a flight may carry MULTIPLE AWB groups (multi-select),
-- and Pieces / KG are computed AUTOMATICALLY from the chosen groups' shipments.
-- Idempotent — safe to run more than once.
-- Run once with:  mysql -u root cargosom < migrate_flight_awb_multi.sql

-- 1) The old per-flight unique AWB is replaced by the flight_awbs junction.
SET @idx=(SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema=DATABASE() AND table_name='flights' AND index_name='uq_flight_awb');
SET @sql=IF(@idx>0,'ALTER TABLE flights DROP INDEX uq_flight_awb','SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- 2) Keep a plain (non-unique) index on flights.awb_no for search / display label.
SET @idx=(SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema=DATABASE() AND table_name='flights' AND index_name='idx_flight_awb');
SET @sql=IF(@idx=0,'ALTER TABLE flights ADD INDEX idx_flight_awb (awb_no)','SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- 3) Junction flight <-> AWB groups (each AWB group on at most ONE flight).
CREATE TABLE IF NOT EXISTS flight_awbs (
    flight_id INT UNSIGNED NOT NULL,
    awb_id INT UNSIGNED NOT NULL,
    PRIMARY KEY (flight_id, awb_id),
    UNIQUE KEY uq_flight_awb_group (awb_id),
    FOREIGN KEY (flight_id) REFERENCES flights(id) ON DELETE CASCADE,
    FOREIGN KEY (awb_id) REFERENCES shipment_awbs(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 4) Backfill: link flights whose awb_no already matches an AWB group.
INSERT IGNORE INTO flight_awbs(flight_id,awb_id)
SELECT f.id,ga.id FROM flights f JOIN shipment_awbs ga ON ga.awb_no=f.awb_no
WHERE NOT EXISTS (SELECT 1 FROM flight_awbs fa WHERE fa.flight_id=f.id AND fa.awb_id=ga.id);

-- 5) Backfill: refresh each flight's label and its Pieces / KG automatically
--    from the shipments of the linked AWB groups.
UPDATE flights f JOIN (
    SELECT fa.flight_id,GROUP_CONCAT(ga.awb_no ORDER BY ga.awb_no DESC SEPARATOR ', ') lb
    FROM flight_awbs fa JOIN shipment_awbs ga ON ga.id=fa.awb_id GROUP BY fa.flight_id
) x ON x.flight_id=f.id SET f.awb_no=x.lb;
UPDATE flights f JOIN (
    SELECT fa.flight_id,COALESCE(SUM(s.pcs),0) p,COALESCE(SUM(s.kg),0) k
    FROM flight_awbs fa
    LEFT JOIN shipment_awb_members gm ON gm.awb_id=fa.awb_id
    LEFT JOIN shipments s ON s.id=gm.shipment_id
    GROUP BY fa.flight_id
) x ON x.flight_id=f.id SET f.pcs=x.p,f.kg=x.k;