-- Migration: link flights <-> shipments
-- Adds flight_id on shipments so every shipment can be assigned to a flight
-- (a flight carries many shipments; one shipment belongs to at most one flight).

ALTER TABLE shipments ADD COLUMN flight_id INT UNSIGNED NULL AFTER fly_awb_no;
ALTER TABLE shipments ADD INDEX idx_ship_flight (flight_id);