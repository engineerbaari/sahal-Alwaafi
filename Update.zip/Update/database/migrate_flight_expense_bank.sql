-- Flight "AWB total expense":
-- The auto expense created when a flight is saved is anchored to its flight the
-- same way the auto income is (income_entries.reference_no = 'FLT-<flight id>').
-- This column lets the expenses row be found / updated / deleted with the flight.
ALTER TABLE expenses ADD COLUMN reference_no VARCHAR(80) NULL AFTER description;