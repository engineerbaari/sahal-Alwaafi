-- Migration: the flight's "AWB Shipment" is read from an AWB Group
-- and each AWB Group may be used by only ONE flight (never multiple).
-- Idempotent — safe to run more than once.
-- Run once with:  mysql -u root cargosom < migrate_flight_awb_unique.sql

-- Remove duplicate flight rows sharing the same awb_no (keeps the first one)
-- so the unique index can always be created.
DELETE f FROM flights f JOIN flights f2 ON f2.awb_no=f.awb_no AND f2.id<f.id;

-- Drop the old non-unique AWB index if it is still present.
SET @idx=(SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema=DATABASE() AND table_name='flights' AND index_name='idx_flight_awb');
SET @sql=IF(@idx>0,'ALTER TABLE flights DROP INDEX idx_flight_awb','SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- Enforce one AWB group per flight.
SET @idx=(SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema=DATABASE() AND table_name='flights' AND index_name='uq_flight_awb');
SET @sql=IF(@idx=0,'ALTER TABLE flights ADD UNIQUE INDEX uq_flight_awb (awb_no)','SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;