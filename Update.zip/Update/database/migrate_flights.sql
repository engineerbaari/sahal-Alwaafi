-- Migration: add the Flights feature
-- Columns: flight date, flight name, AWB shipment, pieces, KG, rate, total (KG x Rate)
-- Run once with:  mysql -u root cargosom < migrate_flights.sql
-- (bootstrap.php also auto-creates this table on first request.)

CREATE TABLE IF NOT EXISTS flights (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    flight_date DATE NOT NULL,
    flight_name VARCHAR(100) NOT NULL,
    awb_no VARCHAR(80) NOT NULL,
    pcs INT UNSIGNED NOT NULL DEFAULT 1,
    kg DECIMAL(12,2) NOT NULL,
    rate DECIMAL(12,2) NOT NULL,
    total DECIMAL(12,2) GENERATED ALWAYS AS (kg * rate) STORED,
    branch_id INT UNSIGNED NOT NULL,
    created_by INT UNSIGNED NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (branch_id) REFERENCES branches(id),
    FOREIGN KEY (created_by) REFERENCES users(id),
    INDEX idx_flight_date (flight_date),
    INDEX idx_flight_name (flight_name),
    INDEX idx_flight_awb (awb_no),
    INDEX idx_flight_branch (branch_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS flight_awbs (
    flight_id INT UNSIGNED NOT NULL,
    awb_id INT UNSIGNED NOT NULL,
    PRIMARY KEY (flight_id, awb_id),
    UNIQUE KEY uq_flight_awb_group (awb_id),
    FOREIGN KEY (flight_id) REFERENCES flights(id) ON DELETE CASCADE,
    FOREIGN KEY (awb_id) REFERENCES shipment_awbs(id) ON DELETE CASCADE
) ENGINE=InnoDB;