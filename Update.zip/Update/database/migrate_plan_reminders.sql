-- Payment-plan reminders ("Xasuusin"):
-- Each instalment can fire ONE reminder; reminded_at records when it was sent.
-- The notifications table (bell in the sidebar) stores the alarms themselves.
ALTER TABLE payment_plans ADD COLUMN reminded_at DATETIME NULL AFTER status;
CREATE TABLE IF NOT EXISTS notifications (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  subject VARCHAR(160) NOT NULL,
  message TEXT NOT NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_notif_user_read (user_id,is_read)
) ENGINE=InnoDB;