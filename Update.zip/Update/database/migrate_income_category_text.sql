-- Income category becomes free text: the income.php form now uses a textbox
-- (with suggestions) instead of a fixed dropdown, so the DB column is widened
-- from an ENUM to a plain string.
ALTER TABLE income_entries MODIFY category VARCHAR(80) NOT NULL;