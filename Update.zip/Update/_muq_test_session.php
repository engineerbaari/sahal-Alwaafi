<?php
$sessionPath=sys_get_temp_dir().'/cargosom-sessions';
session_save_path($sessionPath);
session_id('muqflight03');
session_start();
$_SESSION['user']=['id'=>22,'name'=>'Baari','email'=>'baari@cargosom.test','role'=>'admin','branch_id'=>1,'branch_name'=>'Mogadishu HQ2','permissions'=>'','avatar'=>null,'phone'=>null];
session_write_close();
echo 'SESS-OK';
