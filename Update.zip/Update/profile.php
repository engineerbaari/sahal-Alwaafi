<?php
require __DIR__.'/bootstrap.php';
require_login();
$me = user();

/**
 * Save a profile photo from the avatar file input.
 * Returns the relative path when a new file was saved, or null when no file was chosen.
 * (Same behaviour as the Users section so avatars are interchangeable.)
 */
function save_user_avatar(int $userId, string $oldPath): ?string
{
    if (!isset($_FILES['avatar']) || $_FILES['avatar']['error'] === UPLOAD_ERR_NO_FILE) {
        return null;
    }
    if ($_FILES['avatar']['error'] !== UPLOAD_ERR_OK || $_FILES['avatar']['size'] > 2 * 1024 * 1024) {
        flash('danger', 'Photo upload failed or exceeded the 2 MB limit.');
        redirect('profile.php');
    }
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($_FILES['avatar']['tmp_name']);
    $types = ['image/png' => 'png', 'image/jpeg' => 'jpg', 'image/webp' => 'webp'];
    if (!isset($types[$mime])) {
        flash('danger', 'Photo must be a PNG, JPG, or WebP image.');
        redirect('profile.php');
    }
    $dir = __DIR__ . '/uploads/avatars';
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    $filename = 'av-' . $userId . '-' . bin2hex(random_bytes(6)) . '.' . $types[$mime];
    if (!move_uploaded_file($_FILES['avatar']['tmp_name'], $dir . '/' . $filename)) {
        flash('danger', 'The photo could not be saved.');
        redirect('profile.php');
    }
    if ($oldPath !== '' && is_file(__DIR__ . '/' . $oldPath)) {
        @unlink(__DIR__ . '/' . $oldPath);
    }
    return 'uploads/avatars/' . $filename;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $id = (int) $me['id'];

    $displayName = trim($_POST['name'] ?? '');
    if ($displayName === '') {
        flash('danger', 'Name cannot be empty.');
        redirect('profile.php');
    }

    $sql = 'UPDATE users SET name=?, phone=?';
    $args = [$displayName, trim($_POST['phone'] ?? '')];

    $newPassword = (string) ($_POST['new_password'] ?? '');
    if ($newPassword !== '') {
        if (strlen($newPassword) < 8) {
            flash('danger', 'New password must be at least 8 characters.');
            redirect('profile.php');
        }
        if (!hash_equals($newPassword, (string) ($_POST['confirm_password'] ?? ''))) {
            flash('danger', 'New password confirmation does not match.');
            redirect('profile.php');
        }
        $q = $pdo->prepare('SELECT password FROM users WHERE id=?');
        $q->execute([$id]);
        $storedHash = (string) $q->fetchColumn();
        if ($storedHash === '' || !password_verify((string) ($_POST['current_password'] ?? ''), $storedHash)) {
            flash('danger', 'Your current password is incorrect.');
            redirect('profile.php');
        }
        $sql .= ', password=?';
        $args[] = password_hash($newPassword, PASSWORD_DEFAULT);
    }

    $removeAvatar = isset($_POST['remove_avatar']);
    $hasAvatarUpload = isset($_FILES['avatar']) && $_FILES['avatar']['error'] !== UPLOAD_ERR_NO_FILE;
    if ($removeAvatar || $hasAvatarUpload) {
        $q = $pdo->prepare('SELECT avatar FROM users WHERE id=?');
        $q->execute([$id]);
        $oldAvatar = (string) $q->fetchColumn();
    } else {
        $oldAvatar = '';
    }

    if ($removeAvatar) {
        $sql .= ', avatar=NULL';
        if ($oldAvatar !== '' && is_file(__DIR__ . '/' . $oldAvatar)) {
            @unlink(__DIR__ . '/' . $oldAvatar);
        }
    } elseif ($hasAvatarUpload) {
        $sql .= ', avatar=?';
        $args[] = save_user_avatar($id, $oldAvatar);
    }

    $sql .= ' WHERE id=?';
    $args[] = $id;

    try {
        $pdo->prepare($sql)->execute($args);
        $q = $pdo->prepare('SELECT u.*, b.name branch_name FROM users u JOIN branches b ON b.id=u.branch_id WHERE u.id=?');
        $q->execute([$id]);
        $fresh = $q->fetch();
        if ($fresh) {
            $_SESSION['user'] = [
                'id' => (int) $fresh['id'],
                'name' => $fresh['name'],
                'email' => $fresh['email'],
                'role' => $fresh['role'],
                'branch_id' => (int) $fresh['branch_id'],
                'branch_name' => $fresh['branch_name'],
                'permissions' => $fresh['permissions'] ?? null,
                'avatar' => $fresh['avatar'] ?? null,
                'phone' => $fresh['phone'] ?? null,
            ];
        }
        flash('success', 'Your profile was updated.');
    } catch (PDOException $e) {
        flash('danger', 'The update could not be saved.');
    }
    redirect('profile.php');
}

$title = 'My Profile';
require __DIR__.'/partials/header.php';
?>
<style>
.profile-wrap .page-head{background:linear-gradient(120deg,#0b2742,#1768ac 68%,#39a7f0);padding:1.7rem 1.9rem;border-radius:22px;color:#fff;box-shadow:0 16px 35px #102a4325;position:relative;overflow:hidden}
.profile-wrap .page-head:after{content:'';position:absolute;width:240px;height:240px;right:-90px;top:-140px;border-radius:50%;background:#fff2}
.profile-wrap .page-head h1{font-size:2rem;letter-spacing:-.04em;color:#fff}
.profile-wrap .page-head .text-secondary{color:#dbeafe!important}
.profile-wrap .card{border:1px solid #e2edf8;box-shadow:0 16px 35px #102a4310;border-radius:18px}
.profile-avatar-preview{display:grid;place-items:center;width:132px;height:132px;border-radius:50%;background:linear-gradient(135deg,#1768ac,#2f80ed);color:#fff;font-size:3.2rem;font-weight:800;box-shadow:0 0 0 4px #dbeafe,0 8px 20px #102a431c;overflow:hidden}
.profile-avatar-preview img{display:block;width:100%;height:100%;object-fit:cover;object-position:center}
</style>
<div class="profile-wrap">
<div class="page-head mb-4 d-flex align-items-center gap-3">
    <div>
        <h1 class="h3 fw-bold mb-1">My profile</h1>
        <p class="text-secondary mb-0">Update your name, photo, and password for your <?=e(setting('company_name','CargoSom'))?> account.</p>
    </div>
</div>
<form method="post" enctype="multipart/form-data">
<input type="hidden" name="csrf" value="<?=csrf()?>">
<div class="row g-4">
    <div class="col-lg-5">
        <div class="card p-4 h-100">
            <h2 class="h5 mb-4">Profile photo</h2>
            <div class="text-center mb-4">
                <?php if (!empty($me['avatar'])): ?>
                    <img id="avatarPreviewImg" class="profile-avatar-preview" src="<?=url($me['avatar'])?>" alt="Profile photo">
                    <div id="avatarPreviewInitials" class="profile-avatar-preview d-none"><?=e(strtoupper(substr($me['name'],0,1)))?></div>
                <?php else: ?>
                    <img id="avatarPreviewImg" class="profile-avatar-preview d-none" alt="Profile photo">
                    <div id="avatarPreviewInitials" class="profile-avatar-preview"><?=e(strtoupper(substr($me['name'],0,1)))?></div>
                <?php endif ?>
            </div>
            <div class="mb-3">
                <label class="form-label">Upload a new photo</label>
                <input class="form-control" type="file" name="avatar" accept="image/png,image/jpeg,image/webp" onchange="avatarPreview(this)">
                <div class="form-text">PNG, JPG, or WebP. Maximum 2 MB.</div>
            </div>
            <?php if (!empty($me['avatar'])): ?>
            <div class="form-check form-switch mb-3">
                <input class="form-check-input" type="checkbox" name="remove_avatar" id="removeAvatar">
                <label class="form-check-label" for="removeAvatar">Remove my current photo</label>
            </div>
            <?php endif ?>
            <hr class="my-4">
            <h2 class="h6 mb-1">Account</h2>
            <p class="text-secondary small mb-3">Your access level and branch are managed by an administrator.</p>
            <div class="d-flex align-items-center gap-2 mb-2">
                <i class="bi bi-person-badge text-secondary"></i>
                <span><?=e(ucfirst($me['role']))?></span>
            </div>
            <div class="d-flex align-items-center gap-2 mb-2">
                <i class="bi bi-buildings text-secondary"></i>
                <span><?=e($me['branch_name'] ?? 'Branch '.$me['branch_id'])?></span>
            </div>
            <div class="d-flex align-items-center gap-2">
                <i class="bi bi-at text-secondary"></i>
                <span><?=e($me['email'])?></span>
            </div>
        </div>
    </div>
    <div class="col-lg-7">
        <div class="card p-4">
            <h2 class="h5 mb-4">Personal details</h2>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Full name</label>
                    <input class="form-control" name="name" value="<?=e($me['name'])?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Phone</label>
                    <input class="form-control" name="phone" value="<?=e($me['phone'] ?? '')?>" placeholder="Optional">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Username</label>
                    <input class="form-control" value="<?=e(strstr($me['email'], '@', true) ?: $me['email'])?>" disabled>
                    <div class="form-text">Your username is fixed. Contact an administrator to change it.</div>
                </div>
<hr class="my-4">
            <h2 class="h5 mb-4">Change password</h2>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Current password</label>
                    <input class="form-control" type="password" name="current_password" autocomplete="current-password" placeholder="Required to set a new password">
                </div>
                <div class="col-md-6">
                    <label class="form-label">New password</label>
                    <input class="form-control" type="password" name="new_password" minlength="8" autocomplete="new-password" placeholder="Leave blank to keep your password">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Confirm new password</label>
                    <input class="form-control" type="password" name="confirm_password" minlength="8" autocomplete="new-password">
                    <div class="form-text">Leave the password fields empty to keep your current password.</div>
                </div>
            </div>
            <div class="mt-4">
                <button class="btn btn-primary px-4 py-2" name="update"><i class="bi bi-check2 me-1"></i> Save changes</button>
            </div>
        </div>
    </div>
</div>
</form>
</div>
<script>
function avatarPreview(input) {
    const file = input.files && input.files[0];
    if (!file) return;
    const img = document.getElementById('avatarPreviewImg');
    const initials = document.getElementById('avatarPreviewInitials');
    const reader = new FileReader();
    reader.onload = e => {
        img.src = e.target.result;
        img.classList.remove('d-none');
        initials.classList.add('d-none');
    };
    reader.readAsDataURL(file);
}
</script>
<?php require __DIR__.'/partials/footer.php'; ?>
            </div>