# Deploying CargoSom to Ifastnet (cPanel shared hosting)

CargoSom is a **standard PHP 8.2+ / MySQL** application, so it runs on Ifastnet
shared hosting (cPanel) — no VPS required.

---

## 1) What you need

- Ifastnet cPanel login (or you can use this guide with any cPanel host).
- A domain or subdomain (Ifastnet gives you a free subdomain, e.g.
  `cargosom.ifastnet.com`, and you can add your own domain).
- Decide the URL: this guide puts the app in a folder **`/cargosom`** so it
  appears at `https://yourdomain/cargosom/` (or `https://cargosom.ifastnet.com/cargosom/`).

> Security first: before going live, change the demo admin password.
> Demo users (password `password`): `admin@cargosom.test`, `staff@cargosom.test`,
> `accountant@cargosom.test`, `customer@cargosom.test`.
> Log in as admin → **Profile** → change the password, and also check **Settings**.

---

## 2) Create the database in cPanel

1. In cPanel open **MySQL® Databases**.
2. Create a database, e.g. `cargosom` → it becomes `prefix_cargosom`
   (cPanel adds your username prefix automatically).
3. Create a database user, e.g. `cargosom_db`, give it a strong password.
4. Add the user to the database and grant **ALL PRIVILEGES**.
5. Open **phpMyAdmin**, select your database, go to the **Import** tab and
   import the file **`database/cargosom_deploy.sql`** (this version works on
   cPanel — it does not try to create the database itself).
6. Check that the tables appear: `branches`, `users`, `airlines`,
   `shipments`, `payments`, … If not, import again and watch for error
   messages (usually a wrong database selected or missing privileges).

## 3) Upload the files

1. In cPanel open **File Manager** → **public_html**.
2. Create a folder named **`cargosom`**.
3. Click **Upload** and upload the zip `cargosom-deploy.zip`, then right-click
   it → **Extract** (or extract it on your PC first and upload the folder).
4. After extraction the files must be DIRECTLY inside `public_html/cargosom/`
   (i.e. `public_html/cargosom/login.php`, not
   `public_html/cargosom/cargosom/login.php`).

## 4) Create `config.php` on the server

In `public_html/cargosom/` copy `config.example.php` to `config.php` and edit
it (File Manager → right click → Edit) to match your cPanel database:

```php
<?php
return [
    'db' => [
        'host' => 'localhost',          // on shared hosting this works
        'port' => 3306,
        'name' => 'prefix_cargosom',    // the full cPanel database name
        'user' => 'prefix_cargosom_db', // the cPanel database user
        'pass' => 'YOUR_STRONG_PASSWORD',
    ],
    'app' => [
        'name' => 'CargoSom',
        'base_url' => 'https://yourdomain/cargosom', // your real URL
        'currency' => 'USD',
        'tax_rate' => 0.05,
    ],
];
```

> `base_url` is only a fallback: CargoSom now **auto-detects the site address**
> from every request (normal HTTP pages, LAN, and HTTPS/tunnels), so all links,
> CSS and JS keep working whatever address visitors use.

## 5) Select the PHP version

1. In cPanel open **Select PHP Version** (or **MultiPHP Manager**).
2. For the `/cargosom` folder (or the whole domain) choose **PHP 8.2 or newer**
   (8.5 if available). CargoSom needs PHP 8.2+.
3. Make sure the PHP extension **`pdo_mysql`** (mysqli) is enabled.

## 6) Open your site

- `https://yourdomain/cargosom/` → you should see the login page.
- Login as `admin@cargosom.test` / `password`, **then immediately change
  that password** in Profile → Settings.

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| `Database unavailable` on the page | `config.php` wrong DB name/user/pass, or the SQL was not imported. |
| 500 / 403 errors | Check PHP version is 8.2+, and that files are in the right folder. |
| MySQL import errors | Create the database in cPanel first, then import `cargosom_deploy.sql` into THAT database. |
| Uploads/logo not showing | The `uploads/` folder must be inside `public_html/cargosom/`. |

---

## Going further (optional)

- Ifastnet **VPS**: you can run Apache + MySQL yourself and follow the normal
  `README.md` setup, then clone/copy this project onto the VPS.
- Schedule a backup of your database in cPanel (Backup wizard) — important!
- If you later add a real domain, just update `base_url` — CargoSom detects the
  rest automatically.