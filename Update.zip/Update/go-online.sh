#!/usr/bin/env bash
#
# CargoSom On-Line Launcher
# ---------------------------
# Starts the LAMPP services (Apache + MySQL), verifies the cargosom database,
# and prints every address where the system will be available.
#
# Usage:
#   ./go-online.sh            # first time; it will ask for your sudo password
#
set -u

LAMPP="/opt/lampp"
APP="/opt/lampp/htdocs/cargosom"

if [ ! -f "$APP/config.php" ]; then
  echo "ERROR: $APP/config.php is missing."
  echo "       Run:  cp $APP/config.example.php $APP/config.php"
  echo "       then set the database credentials and base_url."
  exit 1
fi

echo "==> Starting LAMPP (Apache + MySQL)…"
# Prompts for your sudo password the first time, like: sudo /opt/lampp/lampp start
sudo "$LAMPP/lampp" start || { echo "ERROR: LAMPP could not be started."; exit 1; }

echo "==> Waiting for MySQL (port 3306)…"
up=0
for i in $(seq 1 60); do
  if "$LAMPP/bin/mysqladmin" --host=127.0.0.1 --port=3306 --user=root ping >/dev/null 2>&1; then
    up=1; break
  fi
  sleep 1
done
if [ "$up" -ne 1 ]; then
  echo "ERROR: MySQL is not responding on 127.0.0.1:3306."
  exit 1
fi
echo "    MySQL is up."

echo "==> Verifying the 'cargosom' database…"
if "$LAMPP/bin/mysql" --host=127.0.0.1 --port=3306 --user=root -e "USE cargosom" >/dev/null 2>&1; then
  echo "    Database 'cargosom' OK."
else
  echo "    WARNING: database 'cargosom' was not found."
  echo "    Import it once with:  $LAMPP/bin/mysql --host=127.0.0.1 --user=root < $APP/database/cargosom.sql"
fi

echo "==> Waiting for Apache (port 80)…"
sleep 2
code=$(curl -s -o /dev/null -w '%{http_code}' http://localhost/cargosom/login.php 2>/dev/null || echo 000)
case "$code" in
  200|302|303) echo "    Apache is serving CargoSom (HTTP $code)." ;;
  *)           echo "    WARNING: http://localhost/cargosom answered HTTP $code — check: sudo $LAMPP/lampp status";;
esac

echo
echo "==> CargoSom is ON-LINE. Open one of these addresses:"
echo "    • This PC:            http://localhost/cargosom"
for ip in $(hostname -I 2>/dev/null); do
  echo "    • On this network:    http://$ip/cargosom"
done
echo
echo "Note: links, CSS, and JS adapt automatically to whatever address you use."