<?php
require __DIR__.'/bootstrap.php'; require_login();
$me=user();
require_perm('flights.view');
$canManage=can('flights.manage');
$b=require_branch();

/* ---------- POST: save (create/update) or delete ---------- */
if($_SERVER['REQUEST_METHOD']==='POST'){
    verify_csrf(); require_perm('flights.manage');
    $id=(int)($_POST['id']??0);
    if(isset($_POST['delete'])){
        try{
            $pdo->beginTransaction();
            $s=$pdo->prepare('DELETE FROM flights WHERE id=?'.(is_admin()?'':' AND branch_id=?'));
            $s->execute(is_admin()?[$id]:[$id,$b]);
            $old=$pdo->prepare('SELECT id FROM income_entries WHERE reference_no=?');$old->execute(['FLT-'.$id]);$oldId=(int)$old->fetchColumn();
            if($oldId){$pdo->prepare('DELETE FROM bank_transactions WHERE source_table=? AND source_id=?')->execute(['income_entries',$oldId]);$pdo->prepare('DELETE FROM income_entries WHERE id=?')->execute([$oldId]);}
            $eOld=$pdo->prepare('SELECT id FROM expenses WHERE reference_no=?');$eOld->execute(['FLT-'.$id]);$eOldId=(int)$eOld->fetchColumn();
            if($eOldId){$pdo->prepare('DELETE FROM bank_transactions WHERE source_table=? AND source_id=?')->execute(['expenses',$eOldId]);$pdo->prepare('DELETE FROM expenses WHERE id=?')->execute([$eOldId]);}
            $pdo->commit();
            flash('success','Flight record and its auto income / expense deleted.');
        }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();flash('danger','Flight could not be deleted.');}
        redirect('flights.php');
    }
    if(isset($_POST['assign'])){
        $flightId=(int)($_POST['flight_id']??0);
        $shipmentId=(int)($_POST['shipment_id']??0);
        $chk=$pdo->prepare('SELECT id FROM flights WHERE id=?'.(is_admin()?'':' AND branch_id='.$b));$chk->execute([$flightId]);
        if(!$chk->fetch()){flash('danger','Flight not found.');redirect('flights.php');}
        $sc=is_admin()?'':' AND (branch_id='.$b.' OR to_branch_id='.$b.')';
        $chk=$pdo->prepare('SELECT id FROM shipments WHERE id=? AND flight_id IS NULL'.$sc);$chk->execute([$shipmentId]);
        if(!$chk->fetch()){flash('danger','Shipment not found or already assigned to another flight.');redirect('flights.php?g='.$flightId);}
        $pdo->prepare('UPDATE shipments SET flight_id=? WHERE id=?')->execute([$flightId,$shipmentId]);
        flash('success','Shipment added to the flight.');
        redirect('flights.php?g='.$flightId);
    }
    if(isset($_POST['unassign'])){
        $flightId=(int)($_POST['flight_id']??0);
        $shipmentId=(int)($_POST['shipment_id']??0);
        $pdo->prepare('UPDATE shipments SET flight_id=NULL WHERE id=? AND flight_id=?')->execute([$shipmentId,$flightId]);
        flash('success','Shipment removed from the flight.');
        redirect('flights.php?g='.$flightId);
    }
    $date=trim($_POST['flight_date']??'');
    $name=strtoupper(trim($_POST['flight_name']??''));
    $rate=(float)($_POST['rate']??0);
    $branch=is_admin()?((int)($_POST['branch_id']??0)?:require_branch()):require_branch();
    if($date===''||$name===''||$rate<0){
        flash('danger','Please fill in the flight date, flight name and a valid rate.');
        redirect('flights.php'.($id?'?edit='.$id:''));
    }
    /* AWB Shipment: choose MULTIPLE AWB Groups — Pieces & KG come from their shipments. */
    $awbIdsRaw=$_POST['awb_ids']??[];if(!is_array($awbIdsRaw))$awbIdsRaw=is_string($awbIdsRaw)&&$awbIdsRaw!==''?[$awbIdsRaw]:[];
    $awbIds=[];foreach($awbIdsRaw as $x){$n=(int)$x;if($n>0)$awbIds[$n]=$n;}
    if(!$awbIds){flash('danger','Please choose at least one AWB group — the AWB shipment is read from the groups.');redirect('flights.php'.($id?'?edit='.$id:''));}
    $ph=implode(',',array_map(fn($x)=>'?',$awbIds));
    $sel=$pdo->prepare("SELECT ga.id,ga.awb_no,COALESCE(SUM(s.pcs),0) group_pcs,COALESCE(SUM(s.kg),0) group_kg FROM shipment_awbs ga LEFT JOIN shipment_awb_members gm ON gm.awb_id=ga.id LEFT JOIN shipments s ON s.id=gm.shipment_id WHERE ga.id IN ($ph)".(!is_admin()?' AND ga.branch_id='.$b:'')." GROUP BY ga.id");
    $sel->execute(array_keys($awbIds));
    $picked=[];$labels=[];$pcs=0;$kg=0.0;
    foreach($sel->fetchAll() as $r){$picked[(int)$r['id']]=(int)$r['id'];$labels[]=(string)$r['awb_no'];$pcs+=(int)$r['group_pcs'];$kg+=(float)$r['group_kg'];}
    if(count($picked)!==count($awbIds)){flash('danger','One or more chosen AWB groups were not found.');redirect('flights.php'.($id?'?edit='.$id:''));}
    $awb=substr(implode(', ',$labels),0,80);   /* label = the chosen groups' AWB numbers */
    /* Each AWB Group belongs to only ONE flight (never multiple flights). */
    $dupArgs=array_keys($awbIds);$dupArgs[]=$id;
    $dup=$pdo->prepare("SELECT ga.awb_no FROM flight_awbs fa JOIN shipment_awbs ga ON ga.id=fa.awb_id WHERE fa.awb_id IN ($ph) AND fa.flight_id<>?");
    $dup->execute($dupArgs);
    if($dup->fetch()){flash('danger','One of the chosen AWB groups is already on another flight — each AWB group may be on only one flight.');redirect('flights.php'.($id?'?edit='.$id:''));}
    $awbCount=count($awbIds);
    $expenseBankId=(int)($_POST['expense_bank_account_id']??0);if($expenseBankId)$expenseBankId=bank_account_id_for_branch($expenseBankId,$branch);
    try{
        $pdo->beginTransaction();
        if($id){
            $pdo->prepare('DELETE FROM flight_awbs WHERE flight_id=?')->execute([$id]);
            $s=$pdo->prepare('UPDATE flights SET flight_date=?,flight_name=?,awb_no=?,pcs=?,kg=?,rate=?,branch_id=? WHERE id=?'.(is_admin()?'':' AND branch_id='.$b));
            $s->execute([$date,$name,$awb,$pcs,$kg,$rate,$branch,$id]);
        }else{
            $s=$pdo->prepare('INSERT INTO flights(flight_date,flight_name,awb_no,pcs,kg,rate,branch_id,created_by) VALUES(?,?,?,?,?,?,?,?)');
            $s->execute([$date,$name,$awb,$pcs,$kg,$rate,$branch,$me['id']]);
            $id=(int)$pdo->lastInsertId();
        }
        $ins=$pdo->prepare('INSERT INTO flight_awbs(flight_id,awb_id) VALUES(?,?)');
        foreach(array_keys($awbIds) as $aid)$ins->execute([$id,$aid]);
        /* Automatically apply the flight's AWB total to the account (income). */
        $old=$pdo->prepare('SELECT id FROM income_entries WHERE reference_no=?');$old->execute(['FLT-'.$id]);$oldId=(int)$old->fetchColumn();
        if($oldId){$pdo->prepare('DELETE FROM bank_transactions WHERE source_table=? AND source_id=?')->execute(['income_entries',$oldId]);$pdo->prepare('DELETE FROM income_entries WHERE id=?')->execute([$oldId]);}
        $iAmount=(float)$rate*$awbCount;
        $pdo->prepare('INSERT INTO income_entries(income_date,category,amount,shipment_id,bank_account_id,branch_id,payer,payment_method,reference_no,description,recorded_by) VALUES(?,?,?,NULL,?,?,?,?,?,?,?)')->execute([$date,'Cargo Service',$iAmount,null,$branch,'','Cash','FLT-'.$id,'Flight '.$name.' — AWB total ('.$awbCount.' AWB group(s) x '.number_format((float)$rate,2).') = '.number_format($iAmount,2),$me['id']]);
        /* Automatically apply the flight's TOTAL (KG × Rate) as an EXPENSE (money
           out) when an expense bank account is chosen on the form. The row is
           anchored to the flight with reference_no='FLT-<id>' — same trick as the
           auto income. */
        $eOld=$pdo->prepare("SELECT id FROM expenses WHERE reference_no=?");$eOld->execute(['FLT-'.$id]);$expenseId=(int)$eOld->fetchColumn();
        $expAmount=(float)$kg*$rate;   /* Total (KG × Rate) */
        if($expenseBankId||$expenseId){
            $eDesc='Flight '.$name.' — expense (Total '.number_format($kg,2).' KG × '.number_format((float)$rate,2).') = '.number_format($expAmount,2);
            if($expenseId){$pdo->prepare('UPDATE expenses SET category=?,amount=?,expense_date=?,description=?,bank_account_id=? WHERE id=?')->execute(['Cargo',$expAmount,$date,$eDesc,$expenseBankId?:null,$expenseId]);}
            else{$pdo->prepare('INSERT INTO expenses(category,amount,expense_date,vendor,description,status,shipment_id,branch_id,bank_account_id,recorded_by,reference_no) VALUES(?,?,?,?,?,?,?,?,?,?,?)')->execute(['Cargo',$expAmount,$date,'',$eDesc,'Paid',null,$branch,$expenseBankId?:null,$me['id'],'FLT-'.$id]);$expenseId=(int)$pdo->lastInsertId();}
            sync_expense_bank_transaction($expenseId,$expenseBankId,$expAmount,$date.' '.date('H:i:s'));
        }
        $pdo->commit();
        flash('success','Flight '.$name.' saved — '.$awbCount.' AWB group(s), '.$pcs.' pcs, '.number_format($kg,2).' kg · income (cash): AWB total '.number_format($iAmount,2).($expenseBankId?' · expense '.number_format($expAmount,2).' (Total KG × Rate) paid from bank account':'').'.');
    }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();flash('danger','Could not save the flight — check the AWB groups and try again.');}
    redirect('flights.php');
}

/* ---------- Filters (date range + search) ---------- */
$from=trim($_GET['from']??'');$to=trim($_GET['to']??'');$q=trim($_GET['q']??'');
$where=is_admin()?'':' WHERE f.branch_id='.$b;
$args=[];
if($from!==''||$to!==''||$q!==''){
    $parts=[];
    if($from!==''){$parts[]='f.flight_date>=?';$args[]=$from;}
    if($to!==''){$parts[]='f.flight_date<=?';$args[]=$to;}
    if($q!==''){$parts[]='(f.flight_name LIKE ? OR f.awb_no LIKE ?)';$args[]="%$q%";$args[]="%$q%";}
    $where.=($where===''?' WHERE ':' AND ').implode(' AND ',$parts);
}
$rows=$pdo->prepare("SELECT f.*,b.name branch_name,(SELECT COUNT(*) FROM shipments x WHERE x.flight_id=f.id) shipments_count,(SELECT COUNT(*) FROM flight_awbs fa WHERE fa.flight_id=f.id) awb_count,(SELECT COALESCE((SELECT GROUP_CONCAT(ga2.awb_no ORDER BY ga2.awb_no DESC SEPARATOR ', ') FROM flight_awbs fa2 JOIN shipment_awbs ga2 ON ga2.id=fa2.awb_id WHERE fa2.flight_id=f.id),f.awb_no,'')) awb_label,(SELECT bank_account_id FROM expenses ex WHERE ex.reference_no=CONCAT('FLT-',f.id) ORDER BY ex.id DESC LIMIT 1) expense_bank FROM flights f JOIN branches b ON b.id=f.branch_id$where ORDER BY f.flight_date DESC,f.id DESC");
$rows->execute($args);
$rows=$rows->fetchAll();
$sumPcs=0;$sumKg=0.0;$sumTotal=0.0;
foreach($rows as $r){$sumPcs+=(int)$r['pcs'];$sumKg+=(float)$r['kg'];$sumTotal+=(float)$r['total'];}

/* ---------- Row being edited ---------- */
$edit=null;$flightAwbIds=[];
if($canManage&&isset($_GET['edit'])){
    $s=$pdo->prepare('SELECT * FROM flights WHERE id=?'.(is_admin()?'':' AND branch_id='.$b));
    $s->execute([(int)$_GET['edit']]);
    $edit=$s->fetch()?:null;
    if($edit){$st=$pdo->prepare('SELECT awb_id FROM flight_awbs WHERE flight_id=?');$st->execute([(int)$edit['id']]);foreach($st->fetchAll() as $r)$flightAwbIds[(int)$r['awb_id']]=1;
        $edit['expense_bank_account_id']=(int)$pdo->query("SELECT bank_account_id FROM expenses WHERE reference_no='FLT-".(int)$edit['id']."' ORDER BY id DESC LIMIT 1")->fetchColumn()?:0;
    }
}
$branches=$pdo->query('SELECT id,name,code FROM branches WHERE active=1 ORDER BY name')->fetchAll();
$banks=$pdo->query('SELECT id,name,bank_name,account_number FROM bank_accounts WHERE active=1'.(is_admin()?'':' AND branch_id='.$b).' ORDER BY name')->fetchAll();
$awbGroups=$canManage?$pdo->query("SELECT ga.id,ga.awb_no,ga.name,COALESCE(SUM(s.pcs),0) group_pcs,COALESCE(SUM(s.kg),0) group_kg FROM shipment_awbs ga LEFT JOIN shipment_awb_members gm ON gm.awb_id=ga.id LEFT JOIN shipments s ON s.id=gm.shipment_id".(is_admin()?'':' WHERE ga.branch_id='.$b)." GROUP BY ga.id ORDER BY ga.awb_no DESC")->fetchAll():[];

/* ---------- Flight detail (?g=) + linked shipments ---------- */
$g=(int)($_GET['g']??0);
$group=null;$members=[];$unassigned=[];$mPcs=0;$mKg=0.0;$mTotal=0.0;
if($g>0){
    $s=$pdo->prepare('SELECT f.*,b.name branch_name FROM flights f JOIN branches b ON b.id=f.branch_id WHERE f.id=?'.(is_admin()?'':' AND f.branch_id='.$b));
    $s->execute([$g]);$group=$s->fetch()?:null;
}
if($group){
    $sc=is_admin()?'':' AND (s.branch_id='.$b.' OR s.to_branch_id='.$b.')';
    $members=$pdo->query("SELECT s.*,a.code airline FROM shipments s JOIN airlines a ON a.id=s.airline_id WHERE s.flight_id=".(int)$group['id'].$sc." ORDER BY s.shipment_date DESC,s.id DESC")->fetchAll();
    foreach($members as $m){$mPcs+=(int)$m['pcs'];$mKg+=(float)$m['kg'];$mTotal+=(float)$m['total'];}
    $fGroups=$pdo->query("SELECT ga.id,ga.awb_no,ga.name FROM flight_awbs fa JOIN shipment_awbs ga ON ga.id=fa.awb_id WHERE fa.flight_id=".(int)$group['id']." ORDER BY ga.awb_no DESC")->fetchAll();
    $awbCount=count($fGroups);   /* one AWB per group — counted once, never multiple */
    $mCharge=(float)$group['rate']*$awbCount;   /* AWB No × Rate = number of AWB groups */
    $fltExp=$pdo->prepare("SELECT e.amount,e.bank_account_id,b.name bank_name FROM expenses e LEFT JOIN bank_accounts b ON b.id=e.bank_account_id WHERE e.reference_no=? ORDER BY e.id DESC LIMIT 1");
    $fltExp->execute(['FLT-'.$group['id']]);$fltExp=$fltExp->fetch()?:null;
    if($canManage)$unassigned=$pdo->query("SELECT s.id,s.awb,s.sender,s.shipment_date FROM shipments s WHERE s.flight_id IS NULL".(is_admin()?'':' AND (s.branch_id='.$b.' OR s.to_branch_id='.$b.')')." ORDER BY s.shipment_date DESC,s.id DESC")->fetchAll();
}

$title='Flights';require __DIR__.'/partials/header.php';
?>
<div class="d-flex justify-content-between align-items-center mb-4">
  <div>
    <h1 class="h3 fw-bold mb-1">Flights</h1>
    <p class="text-secondary mb-0">Flight date, name, AWB shipment (from MULTIPLE AWB groups — pieces &amp; KG are automatic) and cargo charges.</p>
  </div>
  <?php if($canManage):?><button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#flightModal"><i class="bi bi-plus-lg me-1"></i>Add flight</button><?php endif?>
</div>

<div class="row g-3 mb-4">
  <div class="col-6 col-lg-3"><div class="card metric p-3"><div class="text-secondary small">Flights</div><div class="value"><?=count($rows)?></div></div></div>
  <div class="col-6 col-lg-3"><div class="card metric p-3"><div class="text-secondary small">Pieces</div><div class="value"><?=number_format($sumPcs)?></div></div></div>
  <div class="col-6 col-lg-3"><div class="card metric p-3"><div class="text-secondary small">Total KG</div><div class="value"><?=number_format($sumKg,2)?></div></div></div>
  <div class="col-6 col-lg-3"><div class="card metric p-3"><div class="text-secondary small">Total value</div><div class="value"><?=money($sumTotal)?></div></div></div>
</div>

<form class="card p-3 mb-4" method="get">
  <div class="row g-2">
    <div class="col-md-3"><label class="form-label small">From date</label><input class="form-control" type="date" name="from" value="<?=e($from)?>"></div>
    <div class="col-md-3"><label class="form-label small">To date</label><input class="form-control" type="date" name="to" value="<?=e($to)?>"></div>
    <div class="col-md-4"><label class="form-label small">Search (flight name / AWB)</label><input class="form-control" type="search" name="q" value="<?=e($q)?>" placeholder="e.g. EK 401 or 176-…"></div>
    <div class="col-md-2 d-flex align-items-end gap-2">
      <button class="btn btn-primary w-100"><i class="bi bi-funnel me-1"></i>Filter</button>
      <?php if($from!==''||$to!==''||$q!==''):?><a class="btn btn-outline-secondary" href="flights.php" title="Clear filters"><i class="bi bi-x-lg"></i></a><?php endif?>
    </div>
  </div>
</form>
<div class="card p-3 p-lg-4">
  <div class="table-responsive">
    <table class="table table-hover align-middle">
      <thead><tr><th>Flight date</th><th>Flight name</th><th>AWB Shipment</th><th>Shipments</th><th>Pieces</th><th>KG</th><th>Rate</th><th>Total</th><th>AWB Total</th><?php if(is_admin()):?><th>Branch</th><?php endif?><?php if($canManage):?><th class="text-end">Actions</th><?php endif?></tr></thead>
      <tbody>
      <?php foreach($rows as $r):?>
        <tr>
          <td><?=app_date($r['flight_date'])?></td>
          <td class="fw-semibold"><a class="text-decoration-none text-dark" href="flights.php?g=<?=$r['id']?>" title="Open flight &amp; its shipments"><i class="bi bi-airplane me-1 text-primary"></i><?=e($r['flight_name'])?></a></td>
          <td><?php if(($r['awb_label']??'')!==''):?><?php foreach(explode(', ',(string)$r['awb_label']) as $an):?><span class="badge text-bg-light border me-1"><?=e($an)?></span><?php endforeach?><?php else:?><span class="text-secondary">—</span><?php endif?></td>
          <td><a class="badge text-bg-primary border text-decoration-none" href="flights.php?g=<?=$r['id']?>" title="Open flight shipments"><?=$r['shipments_count']?> ×</a></td>
          <td><?=e($r['pcs'])?> pcs</td>
          <td><?=number_format((float)$r['kg'],2)?> kg</td>
          <td><?=money($r['rate'])?></td>
          <td class="fw-bold"><?=money($r['total'])?></td>
          <td class="fw-bold"><?=money((int)$r['awb_count']*(float)$r['rate'])?></td>
          <?php if(is_admin()):?><td><?=e($r['branch_name'])?></td><?php endif?>
          <?php if($canManage):?><td class="text-end text-nowrap">
            <button type="button" class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#flightModal" data-edit="<?=$r['id']?>" data-date="<?=e($r['flight_date'])?>" data-name="<?=e($r['flight_name'])?>" data-rate="<?=e($r['rate'])?>" data-awbcount="<?=$r['awb_count']?>" data-branch="<?=$r['branch_id']?>" data-expensebank="<?=(int)($r['expense_bank']??0)?>"><i class="bi bi-pencil me-1"></i>Edit</button>
            <form method="post" class="d-inline"><input type="hidden" name="csrf" value="<?=csrf()?>"><input type="hidden" name="id" value="<?=$r['id']?>"><button class="btn btn-sm btn-outline-danger" name="delete" data-confirm="Delete this flight record?"><i class="bi bi-trash"></i></button></form>
          </td><?php endif?>
        </tr>
      <?php endforeach?>
      </tbody>
    </table>
  </div>
  <?php if(!$rows):?><div class="text-center text-secondary py-5"><i class="bi bi-airplane display-6 d-block mb-2"></i>No flights found<?=$q!==''||$from!==''||$to!==''?' for the selected filters':''?> — add one to get started.</div><?php endif?>
</div>
<?php if($group):?>
<div class="card p-3 p-lg-4 mb-4 border-primary border-2" style="border-left:6px solid var(--bs-primary)">
  <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-2">
    <div>
      <h2 class="h5 mb-1"><i class="bi bi-airplane me-2 text-primary"></i>Flight <?=e($group['flight_name'])?></h2>
      <div class="text-secondary small"><?=app_date($group['flight_date'])?> · <?=e($group['branch_name'])?></div>
      <?php if($fGroups):?><div class="d-flex flex-wrap gap-1 mt-1"><?php foreach($fGroups as $fg):?><a class="badge text-bg-info border text-decoration-none" href="shipment_awb.php?g=<?=$fg['id']?>"><i class="bi bi-collection me-1"></i><?=e($fg['awb_no'])?></a><?php endforeach?></div><?php endif?>
    </div>
    <div class="text-end">
      <div class="small text-secondary">Pieces / KG (auto from AWB groups)</div>
      <strong><?=e($group['pcs'])?> pcs · <?=number_format((float)$group['kg'],2)?> kg · <?=money($group['total'])?></strong>
    </div>
  </div>
  <div class="row g-2">
    <div class="col-md-4"><div class="border rounded p-2 bg-body-tertiary"><small class="text-secondary d-block">Loaded pieces</small><strong><?=number_format($mPcs)?></strong></div></div>
    <div class="col-md-4"><div class="border rounded p-2 bg-body-tertiary"><small class="text-secondary d-block">Loaded KG</small><strong><?=number_format($mKg,2)?> kg</strong></div></div>
    <div class="col-md-4"><div class="border rounded p-2 bg-body-tertiary"><small class="text-secondary d-block">Loaded value</small><strong><?=money($mTotal)?></strong></div></div>
  </div>
  <div class="row g-2 mt-2">
    <div class="col-md-6"><div class="border rounded p-2 bg-body-tertiary"><small class="text-secondary d-block">AWB total (<?=$awbCount?> AWB group<?=$awbCount==1?'':'s'?> × <?=number_format((float)$group['rate'],2)?> — each group counted once)</small><strong class="fs-5"><?=money($mCharge)?></strong></div></div>
    <div class="col-md-6"><div class="border rounded p-2 bg-body-tertiary"><small class="text-secondary d-block">Booked total (KG × Rate)</small><strong class="fs-5"><?=money($group['total'])?></strong></div></div>
  </div>
  <?php if($fltExp):?><div class="text-secondary small mt-2"><i class="bi bi-graph-down-arrow me-1 text-danger"></i>Expense (Total KG × Rate) <strong class="text-danger"><?=money($fltExp['amount'])?></strong> paid from <strong><?=e($fltExp['bank_name']?:'Cash')?></strong></div><?php endif?>
</div>

<div class="card p-3 p-lg-4">
  <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-2">
    <h2 class="h5 mb-0">Shipments on this flight (<?=count($members)?>)</h2>
    <?php if($canManage):?>
    <form method="post" class="d-inline-flex flex-wrap align-items-center gap-2">
      <input type="hidden" name="csrf" value="<?=csrf()?>">
      <input type="hidden" name="flight_id" value="<?=$group['id']?>">
      <input class="form-control form-control-sm" id="assignSearch" placeholder="Search AWB…" style="width:150px">
      <select class="form-select form-select-sm" name="shipment_id" style="min-width:280px">
        <option value="">— unassigned shipment —</option>
        <?php foreach($unassigned as $u):?><option value="<?=$u['id']?>" data-s="<?=strtolower(e($u['awb'].' '.$u['sender']))?>"><?=e($u['awb'])?> · <?=e($u['sender'])?> (<?=app_date($u['shipment_date'])?>)</option><?php endforeach?>
      </select>
      <button class="btn btn-sm btn-primary" name="assign"><i class="bi bi-plus-lg me-1"></i>Add shipment</button>
    </form>
    <?php endif?>
  </div>
  <div class="table-responsive">
    <table class="table table-hover align-middle" id="memberTable">
      <thead><tr><th>Date</th><th>AWB</th><th>Sender</th><th>Pieces</th><th>KG</th><th>Rate</th><th>Total</th><th>Status</th><?php if($canManage):?><th class="text-end">Actions</th><?php endif?></tr></thead>
      <tbody>
      <?php foreach($members as $m):?>
        <tr>
          <td><?=date('d M',strtotime($m['shipment_date']))?></td>
          <td class="fw-semibold"><?=e($m['awb'])?><small class="d-block text-secondary"><?=e($m['airline'])?></small></td>
          <td><?=e($m['sender'])?></td>
          <td><?=e($m['pcs'])?></td>
          <td><?=number_format((float)$m['kg'],2)?></td>
          <td><?=money($m['rate'])?></td>
          <td class="fw-bold"><?=money($m['total'])?></td>
          <td><?=e($m['status'])?></td>
          <?php if($canManage):?><td class="text-end"><form method="post" class="d-inline"><input type="hidden" name="csrf" value="<?=csrf()?>"><input type="hidden" name="flight_id" value="<?=$group['id']?>"><input type="hidden" name="shipment_id" value="<?=$m['id']?>"><button class="btn btn-sm btn-outline-secondary" name="unassign" data-confirm="Remove this shipment from the flight? It stays in the register."><i class="bi bi-dash-circle me-1"></i>Remove</button></form></td><?php endif?>
        </tr>
      <?php endforeach?>
      </tbody>
    </table>
  </div>
  <?php if(!$members):?><div class="text-center text-secondary py-4"><i class="bi bi-box-seam display-6 d-block mb-2"></i>No shipments on this flight yet — use "Add shipment" above or assign one from the Shipment register.</div><?php endif?>
  <div class="mt-3"><a class="btn btn-sm btn-outline-secondary" href="flights.php"><i class="bi bi-arrow-left me-1"></i>Back to all flights</a></div>
</div>
<script>window.addEventListener("DOMContentLoaded",()=>{const i=document.querySelector("#assignSearch");if(!i)return;const opts=[...document.querySelectorAll("select[name=shipment_id] option")];i.addEventListener("input",()=>{const q=i.value.toLowerCase();opts.forEach(o=>o.hidden=q!==''&&!((o.dataset.s??'').includes(q)))})})</script>
<?php endif?>
<?php if($canManage):$v=$edit?:['id'=>'','flight_date'=>date('Y-m-d'),'flight_name'=>'','pcs'=>0,'kg'=>0,'rate'=>'','expense_bank_account_id'=>0,'branch_id'=>$b];?>
<div class="modal fade" id="flightModal"><div class="modal-dialog modal-lg"><form method="post" class="modal-content">
  <div class="modal-header"><h2 class="h5 mb-0" id="flightModalTitle">Add flight</h2><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div>
  <div class="modal-body">
    <input type="hidden" name="csrf" value="<?=csrf()?>">
    <input type="hidden" name="id" value="<?=e($v['id'])?>">
    <div class="row g-3">
      <div class="col-md-6"><label class="form-label">Flight date</label><input class="form-control" type="date" name="flight_date" value="<?=e($v['flight_date'])?>" required></div>
      <div class="col-md-6"><label class="form-label">Flight name</label><input class="form-control" name="flight_name" value="<?=e($v['flight_name'])?>" placeholder="e.g. EK 401" required></div>
      <div class="col-md-12"><label class="form-label">AWB Shipment <span class="text-secondary small">(choose one or MORE AWB groups)</span></label><div class="border rounded p-2" style="max-height:180px;overflow-y:auto"><?php if(!$awbGroups):?><div class="text-secondary py-2">No AWB groups yet — <a href="shipment_awb.php">create one first</a>.</div><?php endif?><?php foreach($awbGroups as $ag):?><label class="form-check d-flex align-items-start gap-2 mb-1"><input class="form-check-input awb-pick" type="checkbox" name="awb_ids[]" value="<?=$ag['id']?>" data-pcs="<?=$ag['group_pcs']?>" data-kg="<?=$ag['group_kg']?>" <?=isset($flightAwbIds[(int)$ag['id']])?'checked':''?>><span><?=e($ag['awb_no'])?><?php if(($ag['name']?:'')!==''):?><small class="text-secondary d-block"><?=e($ag['name'])?></small><?php endif?></span><small class="text-secondary ms-auto text-nowrap"><?=number_format((float)$ag['group_pcs'])?> pcs · <?=number_format((float)$ag['group_kg'],2)?> kg</small></label><?php endforeach?></div><div class="form-text">Pieces &amp; KG fill in AUTOMATICALLY from the chosen groups' shipments.</div></div>
      <div class="col-md-6"><label class="form-label">Pieces <span class="text-secondary small">(auto)</span></label><input id="flightPcs" class="form-control" type="number" name="pcs" value="<?=e($v['pcs'])?>" readonly></div>
      <div class="col-md-4"><label class="form-label">KG <span class="text-secondary small">(auto)</span></label><input id="flightKg" class="form-control calc" type="number" step=".01" name="kg" value="<?=e($v['kg'])?>" readonly></div>
      <div class="col-md-4"><label class="form-label">Rate / KG</label><input id="flightRate" class="form-control calc" type="number" min="0" step=".01" name="rate" value="<?=e($v['rate'])?>" required></div>
      <div class="col-md-4"><label class="form-label">Total (KG × Rate)</label><input id="flightTotal" class="form-control" readonly></div>
      <div class="col-md-4"><label class="form-label">AWB total (groups × Rate)</label><input id="flightCharge" class="form-control" readonly></div>
      <div class="col-md-6"><label class="form-label">Bank account <span class="text-secondary small">(expense: Total KG × Rate)</span></label><select class="form-select" name="expense_bank_account_id"><option value="">Cash / not linked</option><?php foreach($banks as $bk):?><option value="<?=$bk['id']?>" <?=(string)($v['expense_bank_account_id']??'')===(string)$bk['id']?'selected':''?>><?=e($bk['name'].' · '.$bk['bank_name'])?></option><?php endforeach?></select><div class="form-text">The flight's Total (KG × Rate) is posted from this account as an expense (money out) when you save.</div></div>
      <?php if(is_admin()):?><div class="col-md-6"><label class="form-label">Branch</label><select class="form-select" name="branch_id"><?php foreach($branches as $b2):?><option value="<?=$b2['id']?>" <?=(int)$v['branch_id']===(int)$b2['id']?'selected':''?>><?=e($b2['name'].' ('.$b2['code'].')')?></option><?php endforeach?></select></div><?php endif?>
    </div>
  </div>
  <div class="modal-footer"><button class="btn btn-primary" name="save"><i class="bi bi-check2 me-1"></i>Save flight</button></div>
</form></div></div>
<script>
window.addEventListener("DOMContentLoaded",()=>{
  const p=document.querySelector("#flightPcs"),k=document.querySelector("#flightKg"),r=document.querySelector("#flightRate"),t=document.querySelector("#flightTotal"),c=document.querySelector("#flightCharge"),m=document.getElementById("flightModal");
  const calc=()=>{
    if(t)t.value=((+k.value||0)*(+r.value||0)).toFixed(2);
    if(c)c.value=((m?parseInt(m.dataset.awbCount||"0",10):0)*(+r.value||0)).toFixed(2);   /* AWB groups × Rate */
  };
  const picks=()=>[...document.querySelectorAll(".awb-pick")];
  const recalc=()=>{
    let n=0,pc=0,kg=0.0;
    picks().forEach(b=>{if(b.checked){n++;pc+=+b.dataset.pcs||0;kg+=+b.dataset.kg||0}});
    if(m)m.setAttribute("data-awb-count",String(n));
    if(p)p.value=String(pc);
    if(k)k.value=kg.toFixed(2);
    calc();
  };
  picks().forEach(b=>b.addEventListener("change",recalc));
  r?.addEventListener("input",calc);calc();
  const title=document.getElementById("flightModalTitle");
  m?.addEventListener("show.bs.modal",e=>{
    const btn=e.relatedTarget;
    const set=(n,v)=>{const el=m.querySelector(`[name="${n}"]`);if(el)el.value=v};
    if(!btn||!btn.dataset.edit){
      title.textContent="Add flight";
      set("id","");set("flight_date",new Date().toISOString().slice(0,10));set("flight_name","");set("rate","");set("expense_bank_account_id","");
      picks().forEach(b=>b.checked=false);
      recalc();
      return;
    }
    title.textContent="Edit flight";
    set("id",btn.dataset.edit);set("flight_date",btn.dataset.date);set("flight_name",btn.dataset.name);set("rate",btn.dataset.rate);set("branch_id",btn.dataset.branch);
    set("expense_bank_account_id",btn.dataset.expensebank??"");
    recalc();
  });
});
</script>
<?php endif?>
<?php require __DIR__.'/partials/footer.php';?>