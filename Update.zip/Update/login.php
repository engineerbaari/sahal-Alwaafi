<?php require __DIR__.'/bootstrap.php';if(user())redirect('dashboard.php');$error='';$flashes=$_SESSION['flash']??[];unset($_SESSION['flash']);if($_SERVER['REQUEST_METHOD']==='POST'){verify_csrf();$s=$pdo->prepare('SELECT u.*,b.name branch_name FROM users u JOIN branches b ON b.id=u.branch_id WHERE u.email=? AND u.active=1 AND b.active=1');$s->execute([trim($_POST['email']??'')]);$u=$s->fetch();if($u&&password_verify($_POST['password']??'',$u['password'])){session_regenerate_id(true);$_SESSION['user']=['id'=>(int)$u['id'],'name'=>$u['name'],'email'=>$u['email'],'role'=>$u['role'],'branch_id'=>(int)$u['branch_id'],'branch_name'=>$u['branch_name'],'permissions'=>$u['permissions']??'','avatar'=>$u['avatar']??null,'phone'=>$u['phone']??null];$pdo->prepare('UPDATE users SET last_login=NOW() WHERE id=?')->execute([$u['id']]);redirect('dashboard.php');}$error='Invalid email or password.';}?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Sign in · <?=e(setting('company_name','CargoSom'))?></title><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet"><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet"><link href="assets/app.css?v=4" rel="stylesheet"><style>
:root{--brand:#1768ac;--brand-dark:#0b3d7a}
*{font-family:Inter,system-ui,sans-serif}
body{min-height:100vh;background:radial-gradient(1200px 620px at 88% -12%,#cfe6fb 0%,transparent 55%),radial-gradient(900px 520px at -8% 108%,#cfe6fb 0%,transparent 55%),linear-gradient(135deg,#eef5fc 0%,#f6fafd 55%,#e6eefb 100%)}
.login-page{min-height:100vh;display:grid;place-items:center;padding:24px}
.login-card{width:min(1000px,100%);border:0;border-radius:24px;overflow:hidden;box-shadow:0 26px 80px rgb(16 42 67 / .17)}
.login-brand{background:linear-gradient(150deg,#081f35 0%,#0b3d7a 55%,#1768ac 100%);color:#fff;padding:3.1rem 2.6rem;position:relative;overflow:hidden;display:flex;flex-direction:column;justify-content:space-between}
.login-brand:before{content:'';position:absolute;width:340px;height:340px;border-radius:50%;right:-130px;top:-130px;background:radial-gradient(circle at 30% 30%,#ffffff26,transparent 62%)}
.login-brand:after{content:'';position:absolute;width:240px;height:240px;border-radius:50%;left:-90px;bottom:-90px;background:radial-gradient(circle at 50% 50%,#ffffff14,transparent 66%)}
.login-brand h1,.login-brand .brand-copy,.login-brand .brand-mark{position:relative;z-index:1}
.brand-mark{width:60px;height:60px;border-radius:16px;background:linear-gradient(135deg,#2f80ed,#39a7f0);display:grid;place-items:center;font-weight:800;font-size:1.35rem;box-shadow:0 12px 26px #00000038;margin-bottom:1.6rem}
.login-brand h1{font-weight:800;letter-spacing:-.03em;margin-bottom:.6rem}
.login-brand .brand-copy{color:#dbeafe;opacity:.9;font-size:1.02rem;max-width:34ch}
.login-form-panel{background:#fff;padding:3rem 3.25rem;display:flex;flex-direction:column;justify-content:center}
.login-form-panel h2{font-weight:800;letter-spacing:-.02em}
.login-input{border-radius:12px;overflow:hidden;box-shadow:0 2px 10px rgb(16 42 67 / .06)}
.login-input .input-group-text{background:#fff;border:1px solid #d7e6f5;border-right:0;color:#7a90a8;padding-inline:14px}
.login-input .form-control{border:1px solid #d7e6f5;border-left:0;padding:.82rem .95rem;box-shadow:none}
.login-input .form-control:focus{border-color:#6bb3ec;box-shadow:inset 0 0 0 3px rgb(23 104 172 / .10)}
.btn-show-password{border:1px solid #d7e6f5;border-left:0;background:#fff;color:#7a90a8;padding-inline:14px}
.btn-show-password:hover{background:#f2f8ff;color:#0b3d7a}
.login-submit{background:linear-gradient(90deg,#0b3d7a,#1768ac);border:0;border-radius:12px;padding:.9rem;font-weight:700;letter-spacing:.01em;box-shadow:0 12px 24px rgb(23 104 172 / .28);transition:.2s}
.login-submit:hover{background:linear-gradient(90deg,#0a3468,#155f9c);box-shadow:0 14px 28px rgb(23 104 172 / .34);transform:translateY(-1px)}
.alert{border-radius:12px}
.demo-note{font-size:.8rem;color:#6b7c93}
@media(max-width:767px){.login-card{max-width:460px;border-radius:18px}.login-form-panel{padding:2.1rem 1.4rem}.login-brand{padding:1.9rem 1.2rem}.login-brand h1{font-size:1.55rem}.login-brand .brand-copy{font-size:.92rem}}
</style></head><body>
<div class="login-page">
  <div class="card login-card">
    <div class="row g-0">
      <div class="col-md-5 login-brand">
        <div>
          <div class="brand-mark"><?=e(strtoupper(substr(setting('company_name','CargoSom'),0,2)))?></div>
          <h1 class="display-6"><?=e(setting('company_name','CargoSom'))?></h1>
          <p class="brand-copy">One clear view of every shipment and every dollar.</p>
        </div>
      </div>
      <div class="col-md-7 login-form-panel">
        <h2 class="mb-1">Welcome back</h2>
        <p class="text-secondary mb-4">Sign in to continue to your operations workspace.</p>
        <?php foreach($flashes as [$type,$message]):?><div class="alert alert-<?=e($type)?> alert-dismissible fade show"><?=e($message)?><button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div><?php endforeach?>
        <?php if($error):?><div class="alert alert-danger"><?=e($error)?></div><?php endif?>
        <form method="post">
          <input type="hidden" name="csrf" value="<?=csrf()?>">
          <div class="mb-3">
            <label class="form-label fw-semibold">Username</label>
            <div class="input-group login-input">
              <span class="input-group-text"><i class="bi bi-person"></i></span>
              <input class="form-control" type="text" name="username" placeholder="Your username" required autofocus>
            </div>
          </div>
          <div class="mb-4">
            <label class="form-label fw-semibold">Password</label>
            <div class="input-group login-input">
              <span class="input-group-text"><i class="bi bi-lock"></i></span>
              <input class="form-control" type="password" name="password" id="loginPassword" placeholder="Your password" required>
              <button class="btn btn-show-password" type="button" id="togglePassword" tabindex="-1" aria-label="Show password"><i class="bi bi-eye"></i></button>
            </div>
          </div>
          <button class="btn btn-primary w-100 login-submit" type="submit">Sign in <i class="bi bi-arrow-right ms-1"></i></button>
        </form>
        <p class="demo-note text-center mt-4 mb-0"><i class="bi bi-shield-lock me-1"></i>Secured sign in · Contact your administrator if you need access.</p>
      </div>
    </div>
  </div>
</div>
<script>
document.getElementById('togglePassword').addEventListener('click',function(){var i=document.getElementById('loginPassword'),b=this.querySelector('i');if(i.type==='password'){i.type='text';b.className='bi bi-eye-slash';}else{i.type='password';b.className='bi bi-eye';}});
</script>
</body></html>